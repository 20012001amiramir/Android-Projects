package com.example.android

data class Sport(
    var name: String,
    var desc: String,
    var image: Int
)
